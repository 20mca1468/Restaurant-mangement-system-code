  <footer class="main-footer">
    <div class="pull-right hidden-xs">
    </div>
    <strong>Restaurant Management System</strong>
  </footer>

  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

</body>
</html>
